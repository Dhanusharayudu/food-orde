package com.foodordering.system.config;

import com.foodordering.system.entity.FoodItem;
import com.foodordering.system.repository.FoodItemRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DataInitializer {
    @Bean
    CommandLineRunner seedFood(FoodItemRepository foods) {
        return args -> {
            if (foods.count() == 0) {
                foods.save(new FoodItem("Classic Burger", "Burgers", "Juicy burger with lettuce and house sauce.", 149, "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=900&q=80"));
                foods.save(new FoodItem("Margherita Pizza", "Pizza", "Cheese, tomato and fresh basil.", 249, "https://images.unsplash.com/photo-1574071318508-1cdbab80d002?auto=format&fit=crop&w=900&q=80"));
                foods.save(new FoodItem("Creamy Pasta", "Pasta", "Creamy pasta with herbs and parmesan.", 219, "https://images.unsplash.com/photo-1473093295043-cdd812d0e601?auto=format&fit=crop&w=900&q=80"));
                foods.save(new FoodItem("Crispy French Fries", "Sides", "Golden, crispy seasoned fries.", 99, "https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&w=900&q=80"));
                foods.save(new FoodItem("Veggie Wrap", "Wraps", "Fresh vegetables wrapped with tangy sauce.", 129, "https://images.unsplash.com/photo-1626700051175-6818013e1d4f?auto=format&fit=crop&w=900&q=80"));
                foods.save(new FoodItem("Chocolate Dessert", "Desserts", "Rich chocolate dessert for a sweet finish.", 119, "https://images.unsplash.com/photo-1563729784474-d77dbb933a9e?auto=format&fit=crop&w=900&q=80"));
            }
        };
    }
}
