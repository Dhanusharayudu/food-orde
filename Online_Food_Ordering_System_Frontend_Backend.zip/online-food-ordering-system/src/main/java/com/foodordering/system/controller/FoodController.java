package com.foodordering.system.controller;

import com.foodordering.system.entity.FoodItem;
import com.foodordering.system.repository.FoodItemRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/foods")
public class FoodController {
    private final FoodItemRepository foods;
    public FoodController(FoodItemRepository foods) { this.foods = foods; }

    @GetMapping
    public List<FoodItem> all() {
        return foods.findAll().stream().filter(FoodItem::isAvailable).toList();
    }

    @GetMapping("/{id}")
    public ResponseEntity<FoodItem> one(@PathVariable Long id) {
        return foods.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }
}
