package com.foodordering.system.controller;

import com.foodordering.system.entity.FoodItem;
import com.foodordering.system.entity.FoodOrder;
import com.foodordering.system.repository.FoodItemRepository;
import com.foodordering.system.repository.FoodOrderRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/orders")
public class OrderController {
    private final FoodOrderRepository orders;
    private final FoodItemRepository foods;
    public OrderController(FoodOrderRepository orders, FoodItemRepository foods) {
        this.orders = orders;
        this.foods = foods;
    }

    @GetMapping
    public List<FoodOrder> all() {
        return orders.findAllByOrderByCreatedAtDesc();
    }

    @GetMapping("/{id}")
    public ResponseEntity<FoodOrder> one(@PathVariable Long id) {
        return orders.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<?> place(@RequestBody Map<String, Object> body) {
        String customerName = String.valueOf(body.getOrDefault("customerName", "")).trim();
        String customerEmail = String.valueOf(body.getOrDefault("customerEmail", "")).trim();
        Object rawItems = body.get("items");
        if (customerName.isBlank() || customerEmail.isBlank() || !(rawItems instanceof List<?> itemList) || itemList.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("message", "Name, email and at least one cart item are required."));
        }

        double total = 0;
        List<String> summary = new ArrayList<>();
        for (Object raw : itemList) {
            if (!(raw instanceof Map<?, ?> item)) {
                return ResponseEntity.badRequest().body(Map.of("message", "Invalid cart item."));
            }
            long id;
            int quantity;
            try {
                id = Long.parseLong(String.valueOf(item.get("foodId")));
                quantity = Integer.parseInt(String.valueOf(item.get("quantity")));
            } catch (Exception ex) {
                return ResponseEntity.badRequest().body(Map.of("message", "Each item needs foodId and quantity."));
            }
            if (quantity < 1 || quantity > 99) {
                return ResponseEntity.badRequest().body(Map.of("message", "Quantity must be between 1 and 99."));
            }
            Optional<FoodItem> food = foods.findById(id);
            if (food.isEmpty() || !food.get().isAvailable()) {
                return ResponseEntity.badRequest().body(Map.of("message", "A selected food item is unavailable."));
            }
            FoodItem f = food.get();
            total += f.getPrice() * quantity;
            summary.add(f.getName() + " x " + quantity);
        }

        FoodOrder order = new FoodOrder();
        order.setCustomerName(customerName);
        order.setCustomerEmail(customerEmail);
        order.setItemsSummary(String.join(", ", summary));
        order.setTotal(Math.round(total * 100.0) / 100.0);
        order.setStatus("RECEIVED");
        FoodOrder saved = orders.save(order);
        return ResponseEntity.status(HttpStatus.CREATED).body(Map.of(
            "message", "Order placed successfully.", "orderId", saved.getId(),
            "total", saved.getTotal(), "status", saved.getStatus()
        ));
    }
}
