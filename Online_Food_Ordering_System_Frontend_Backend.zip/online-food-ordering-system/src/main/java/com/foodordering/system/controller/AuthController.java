package com.foodordering.system.controller;

import com.foodordering.system.entity.CustomerAccount;
import com.foodordering.system.repository.CustomerAccountRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private final CustomerAccountRepository accounts;
    public AuthController(CustomerAccountRepository accounts) { this.accounts = accounts; }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody Map<String, String> body) {
        String name = body.getOrDefault("name", "").trim();
        String email = body.getOrDefault("email", "").trim().toLowerCase();
        String password = body.getOrDefault("password", "");
        if (name.isBlank() || email.isBlank() || password.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("message", "Name, email and password are required."));
        }
        if (accounts.findByEmailIgnoreCase(email).isPresent()) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(Map.of("message", "This email is already registered."));
        }
        CustomerAccount saved = accounts.save(new CustomerAccount(name, email, password));
        return ResponseEntity.status(HttpStatus.CREATED).body(Map.of(
            "message", "Registration successful.", "id", saved.getId(), "name", saved.getName(), "email", saved.getEmail()
        ));
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> body) {
        String email = body.getOrDefault("email", "").trim();
        String password = body.getOrDefault("password", "");
        return accounts.findByEmailIgnoreCase(email)
            .filter(account -> account.getPassword().equals(password))
            .<ResponseEntity<?>>map(account -> ResponseEntity.ok(Map.of(
                "message", "Login successful.", "id", account.getId(), "name", account.getName(), "email", account.getEmail()
            )))
            .orElseGet(() -> ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("message", "Invalid email or password.")));
    }
}
