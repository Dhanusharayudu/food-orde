const API = "";
let allFoods = [];
let activeCategory = "All";
let cart = JSON.parse(localStorage.getItem("craveCart") || "[]");
let authMode = "login";

const foodGrid = document.getElementById("foodGrid");
const categoryFilters = document.getElementById("categoryFilters");
const searchInput = document.getElementById("searchInput");
const cartCount = document.getElementById("cartCount");
const toast = document.getElementById("toast");

function money(value) {
  return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(value);
}
function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 2400);
}
async function api(path, options = {}) {
  const response = await fetch(API + path, {
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || `Request failed (${response.status})`);
  return data;
}
async function loadFoods() {
  try {
    allFoods = await api("/api/foods");
    renderFilters();
    renderFoods();
  } catch (error) {
    foodGrid.innerHTML = `<p class="loading">Could not load the menu. Make sure the Spring Boot backend is running. (${escapeHtml(error.message)})</p>`;
  }
}
function renderFilters() {
  const categories = ["All", ...new Set(allFoods.map(food => food.category))];
  categoryFilters.innerHTML = categories.map(category =>
    `<button class="filter ${category === activeCategory ? "active" : ""}" data-category="${escapeHtml(category)}">${escapeHtml(category)}</button>`
  ).join("");
  categoryFilters.querySelectorAll("button").forEach(button => button.addEventListener("click", () => {
    activeCategory = button.dataset.category;
    renderFilters();
    renderFoods();
  }));
}
function renderFoods() {
  const term = searchInput.value.trim().toLowerCase();
  const filtered = allFoods.filter(food =>
    (activeCategory === "All" || food.category === activeCategory) &&
    `${food.name} ${food.category} ${food.description}`.toLowerCase().includes(term)
  );
  if (!filtered.length) {
    foodGrid.innerHTML = '<p class="loading">No food items found. Try another search.</p>';
    return;
  }
  foodGrid.innerHTML = filtered.map(food => `
    <article class="food-card">
      <img src="${escapeHtml(food.imageUrl || "")}" alt="${escapeHtml(food.name)}" loading="lazy"
        onerror="this.src='https://placehold.co/800x500/f1eadc/345b42?text=Food'">
      <div class="food-info">
        <div class="food-meta"><h3>${escapeHtml(food.name)}</h3><span class="food-price">${money(food.price)}</span></div>
        <p>${escapeHtml(food.description || "")}</p>
        <div class="food-bottom"><span class="category-tag">${escapeHtml(food.category)}</span><button class="add-button" data-add="${food.id}">+ Add to cart</button></div>
      </div>
    </article>`).join("");
  foodGrid.querySelectorAll("[data-add]").forEach(button => button.addEventListener("click", () => addToCart(Number(button.dataset.add))));
}
function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[char]));
}
function saveCart() {
  localStorage.setItem("craveCart", JSON.stringify(cart));
  updateCartCount();
  renderCart();
}
function updateCartCount() {
  cartCount.textContent = cart.reduce((sum, item) => sum + item.quantity, 0);
}
function addToCart(id) {
  const food = allFoods.find(item => item.id === id);
  if (!food) return;
  const existing = cart.find(item => item.foodId === id);
  if (existing) existing.quantity++;
  else cart.push({ foodId: id, name: food.name, price: food.price, quantity: 1 });
  saveCart();
  showToast(`${food.name} added to cart`);
}
function changeQuantity(id, amount) {
  const item = cart.find(entry => entry.foodId === id);
  if (!item) return;
  item.quantity += amount;
  if (item.quantity <= 0) cart = cart.filter(entry => entry.foodId !== id);
  saveCart();
}
function renderCart() {
  const container = document.getElementById("cartItems");
  if (!cart.length) container.innerHTML = '<p class="loading">Your cart is empty. Add something delicious!</p>';
  else container.innerHTML = cart.map(item => `
    <div class="cart-row">
      <div><strong>${escapeHtml(item.name)}</strong><small>${money(item.price)} each</small></div>
      <div class="quantity"><button data-minus="${item.foodId}" aria-label="Decrease quantity">−</button><span>${item.quantity}</span><button data-plus="${item.foodId}" aria-label="Increase quantity">+</button></div>
    </div>`).join("");
  container.querySelectorAll("[data-minus]").forEach(button => button.addEventListener("click", () => changeQuantity(Number(button.dataset.minus), -1)));
  container.querySelectorAll("[data-plus]").forEach(button => button.addEventListener("click", () => changeQuantity(Number(button.dataset.plus), 1)));
  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  document.getElementById("cartTotal").textContent = money(total);
  document.getElementById("checkoutOpen").disabled = cart.length === 0;
  document.getElementById("checkoutOpen").style.opacity = cart.length ? "1" : ".5";
}
function openOverlay(id) { document.getElementById(id).classList.add("show"); }
function closeOverlay(id) { document.getElementById(id).classList.remove("show"); }

document.getElementById("cartOpen").addEventListener("click", () => { renderCart(); openOverlay("cartOverlay"); });
document.getElementById("checkoutOpen").addEventListener("click", () => {
  if (!cart.length) return;
  closeOverlay("cartOverlay");
  openOverlay("checkoutOverlay");
});
document.getElementById("loginOpen").addEventListener("click", () => openOverlay("loginOverlay"));
document.querySelectorAll("[data-close]").forEach(button => button.addEventListener("click", () => closeOverlay(button.dataset.close)));
document.querySelectorAll(".overlay").forEach(overlay => overlay.addEventListener("click", event => {
  if (event.target === overlay) closeOverlay(overlay.id);
}));
searchInput.addEventListener("input", renderFoods);

document.getElementById("checkoutForm").addEventListener("submit", async event => {
  event.preventDefault();
  const form = new FormData(event.target);
  const message = document.getElementById("checkoutMessage");
  const payload = {
    customerName: form.get("customerName").trim(),
    customerEmail: form.get("customerEmail").trim(),
    items: cart.map(item => ({ foodId: item.foodId, quantity: item.quantity }))
  };
  try {
    const result = await api("/api/orders", { method: "POST", body: JSON.stringify(payload) });
    message.textContent = `Order #${result.orderId} placed! Total: ${money(result.total)}. Status: ${result.status}.`;
    cart = [];
    saveCart();
    event.target.reset();
    showToast("Your order has been placed!");
    setTimeout(() => closeOverlay("checkoutOverlay"), 3500);
  } catch (error) {
    message.textContent = error.message;
  }
});

document.querySelectorAll("[data-tab]").forEach(button => button.addEventListener("click", () => {
  authMode = button.dataset.tab;
  document.querySelectorAll("[data-tab]").forEach(tab => tab.classList.toggle("active", tab === button));
  document.getElementById("nameField").classList.toggle("hidden", authMode !== "register");
  document.getElementById("authSubmit").textContent = authMode === "register" ? "Create account →" : "Login →";
  document.getElementById("authMessage").textContent = "";
}));
document.getElementById("authForm").addEventListener("submit", async event => {
  event.preventDefault();
  const form = new FormData(event.target);
  const payload = Object.fromEntries(form.entries());
  const message = document.getElementById("authMessage");
  try {
    const result = await api(`/api/auth/${authMode === "register" ? "register" : "login"}`, {
      method: "POST", body: JSON.stringify(payload)
    });
    message.textContent = `${result.message} Hello, ${result.name}!`;
    localStorage.setItem("craveCustomer", JSON.stringify({ name: result.name, email: result.email }));
    showToast(result.message);
    event.target.reset();
  } catch (error) {
    message.textContent = error.message;
  }
});

updateCartCount();
renderCart();
loadFoods();
