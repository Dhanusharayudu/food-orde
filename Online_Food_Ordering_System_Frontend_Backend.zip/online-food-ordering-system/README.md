# Online Food Ordering System

A starter full-stack project with a web frontend and Java Spring Boot backend.

## Requirements
- JDK 17 or later
- Maven 3.9+
- VS Code (recommended)

This version uses an embedded H2 database so it can run without installing MySQL. Data is stored in the local H2 file database under the project folder.

## Run in VS Code
1. Extract the ZIP.
2. Open the `online-food-ordering-system` folder in VS Code.
3. Open Terminal → New Terminal.
4. Run:
   ```powershell
   mvn spring-boot:run
   ```
5. Open http://localhost:8080

## Features
- Responsive food menu
- Search food items
- Add/remove items in cart
- Place orders
- View recent orders
- Register and log in (basic demonstration endpoints)
- Spring Boot REST API
- H2 local database

## API endpoints
- `GET /api/foods`
- `GET /api/foods/{id}`
- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/orders`
- `GET /api/orders`
- `GET /api/orders/{id}`

## Important
This is an educational starter project, not production-ready authentication. Passwords are not intended for real-world use in this demo. Before public deployment, add secure password hashing, authorization, payment-provider integration, validation, and production database settings.
